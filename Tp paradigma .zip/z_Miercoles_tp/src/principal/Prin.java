package principal;
import clases.*;
import java.util.*;

public class Prin {
	
	static Scanner scan = new Scanner(System.in);

	public static void main(String[] args) {
		
		Venta venta = new Venta();
    	venta.inicializarVenta();
		Stock stock = new Stock();
		stock.inicializar();
		String num;

		
		while (true) {
			while(true) {
				System.out.println("Ingrese '1' para manejar el Stock\nIngrese '2' para manejar la caja\nIngrese '3' para cerrar el programa");
				num = scan.nextLine();
				if (num.equals("1") || num.equals("2") || num.equals("3")) {
					break;
				}
				else {
					System.out.println();
					System.out.println("El valor ingresado es invalido.");
					System.out.println();
				}
			}
			
// 1. Manejar stock:
			if (num.equals("1")) {
				while (true) {
					
					String num2;
					while (true) {
						System.out.println("\nIngrese '1' para cargar nuevo stock\ningrese '2' para modificar la cantidad de stock de algun producto\nIngrese '3' para ver el listado de productos\nIngrese '4' para dar de baja un producto\nIngrese '5' para retroceder");
						num2 = scan.nextLine();
						System.out.println();
						if (num2.equals("1") || num2.equals("2") || num2.equals("3") || num2.equals("4") || num2.equals("5")) {
							break;
						}
						else {
							System.out.println("El valor ingresado es invalido.");


						}
					}
					
// 		1.1 Cargar Stock:
					if (num2.equals("1")) {
						int codigo = 0;
						String descripcion;
						int precioUnitario;
						int cantStock;
						int stockMin;
						
						// 1.1.1 carga del codigo del producto
						while (true){
							System.out.println("Ingrese el codigo del producto que desea añadir (-1 para cancelar la carga): ");
							
							try {
					            codigo = scan.nextInt();
					            if (codigo > 0 || codigo == -1) {
					            	break;
					            }
					            else {
						            System.out.println("Error: ingrese un valor valido (no se permiten numeros negativos).");
					            }
					        } catch (InputMismatchException e) {
					            System.out.println("Error: debe ingresar un número entero.");
					            scan.nextLine();
					        }
						}
						if (codigo == -1) {
				            System.out.println("Operacion cancelada.");
				            scan.nextLine();
							continue;
						}
						scan.nextLine();
						
						// 1.1.2 carga de la descripcion del producto
						System.out.println("Ingrese la descripcion del producto que desea añadir (-1 para cancelar la carga): ");
						descripcion = scan.nextLine();
						if (descripcion.equals("-1")) {
							System.out.println("Operacion cancelada.");
							continue;
						}
						// 1.1.3 carga del precio unitario del producto
						while (true){
							System.out.println("Ingrese el precio unitario del producto que desea añadir (-1 para cancelar la operacion): ");
							
							try {
								precioUnitario = scan.nextInt();
					            if (precioUnitario > 0 || precioUnitario == -1) {
					            	break;
					            }
					            else {
						            System.out.println("Error: ingrese un valor valido (no se permiten numeros negativos).");
					            }
					        } catch (InputMismatchException e) {
					            System.out.println("Error: debe ingresar un número entero.");
					            scan.nextLine();
					        }
						}
						if (precioUnitario == -1) {
							System.out.println("Operacion cancelada.");
							scan.nextLine();
							continue;
						}
						
						// 1.1.4 carga del stock actual del producto
						while (true){
							System.out.println("Ingrese el stock actual del producto que desea añadir (-1 para cancelar la operacion): ");
							
							try {
					            cantStock = scan.nextInt();
					            if (cantStock > 0 || cantStock == -1) {
						            break;
					            }
					            else {
						            System.out.println("Error: ingrese un valor valido (no se permiten numeros negativos).");

					            }
					        } catch (InputMismatchException e) {
					            System.out.println("Error: debe ingresar un número entero.");
					            scan.nextLine();
					        }
						}
						if (cantStock == -1){
							System.out.println("Operacion cancelada.");
							scan.nextLine();
							continue;
						}
						
						// 1.1.5 carga del stock minimo del producto
						while (true){
							System.out.println("Ingrese el stock minimo que debe tener el producto que desea añadir (-1 para cancelar la operacion): ");
							
							try {
								stockMin = scan.nextInt();
					            if (stockMin > 0 || stockMin == -1) {
						            break;
					            }
					            else {
						            System.out.println("Error: ingrese un valor valido (no se permiten numeros negativos).");
					            }
						    } catch (InputMismatchException e) {
						        System.out.println("Error: debe ingresar un número entero.");
						        scan.nextLine();
						    }
						}
						if (stockMin == -1){
							System.out.println("Operacion cancelada.");
							scan.nextLine();
							continue;
						}
						
						// 1.1.6 confirmacion de agregacion de producto
						String seguro = "0";
						boolean y = false;
						scan.nextLine();
						while (true) {
					        System.out.println("Esta seguro que quiere agregar el producto seleccionado al stock? (ingrese 'si' para continuar, o 'no' para cancelar la operacion)");
					        seguro = scan.nextLine();
					        if (seguro.equals("si")) {
					        	break;
					        }
					        else if (seguro.equals("no")) {
					        	y = true;
					        	break;
					        }
					        else {
					        	System.out.println("Ingrese una opcion valida.");
					        }
						}
						if (y == true) {
							System.out.println("Operacion cancelada.");
							continue;
						}
						stock.agregarStock(codigo, descripcion, precioUnitario, cantStock, stockMin);
					}
					
// 		1.2 Modificar Stock:
					else if (num2.equals("2")) {
						int codigo;
						int cantStock;
						
						// 1.2.1 codigo elegido para modificar stock
						while (true){
							System.out.println("Ingrese el codigo del producto que desea modificar (-1 para cancelar la operacion): ");
							
							try {
								codigo = scan.nextInt();
					            if (codigo > 0 || codigo == -1) {
					            	break;
					            }
					            else {
						            System.out.println("Error: ingrese un valor valido (no se permiten numeros negativos).");
					            }
					        } catch (InputMismatchException e) {
					            System.out.println("Error: debe ingresar un número entero.");
					            scan.nextLine();
					        }
						}
						if (codigo == -1) {
							System.out.println("Operacion cancelada.");
							scan.nextLine();
							continue;
						}
						
						// 1.2.2 modificar stock segun el codigo dado
						while (true){
							System.out.println("Ingrese el nuevo stock del producto seleccionado (-1 para cancelar la operacion): ");
							
							try {
								cantStock = scan.nextInt();
					            if (cantStock > 0 || cantStock == -1) {
					            	break;
					            }
					            else {
						            System.out.println("Error: ingrese un valor valido (no se permiten numeros negativos).");
					            }
					        } catch (InputMismatchException e) {
					            System.out.println("Error: debe ingresar un número entero.");
					            scan.nextLine();
					        }
						}
						if (cantStock == -1) {
							System.out.println("Operacion cancelada.");
							scan.nextLine();
							continue;
						}
						
						// 1.2.3 confirmacion de cambio
						String seguro = "0";
						boolean y = false;
						scan.nextLine();
						while (true) {
					        System.out.println("Esta seguro que quiere modificar el stock del producto seleccionado? (ingrese 'si' para continuar, o 'no' para cancelar la operacion)");
					        seguro = scan.nextLine();
					        if (seguro.equals("si")) {
					        	break;
					        }
					        else if (seguro.equals("no")) {
					        	y = true;
					        	break;
					        }
					        else {
					        	System.out.println("Ingrese una opcion valida.");
					        }
						}
						if (y == true) {
							System.out.println("Operacion cancelada.");
							continue;
						}
						stock.actualizarStock(codigo, cantStock);
					}
					
// 		1.3 Ver lista de productos:
					else if (num2.equals("3")) {
						stock.listado();
					}
					
// 		1.4 Dar de baja un producto:
					else if (num2.equals("4")) {
						int codigo;
						
						while (true){
							System.out.println("Ingrese el codigo del producto que desea dar de baja (-1 para cancelar la operacion): ");
							
							// 1.4.1 codigo del producto que se desea dar de baja
							try {
								codigo = scan.nextInt();
					            if (codigo > 0 || codigo == -1) {
					            	break;
					            }
					            else {
						            System.out.println("Error: ingrese un valor valido (no se permiten numeros negativos).");
					            }
					        } catch (InputMismatchException e) {
					            System.out.println("Error: debe ingresar un número entero.");
					            scan.nextLine();
					        }
						}
						if (codigo == -1) {
							System.out.println("Operacion cancelada.");
							scan.nextLine();
							continue;
						}
						
						//1.4.2 confirmacion de dar de baja un producto
						String seguro = "0";
						boolean y = false;
						scan.nextLine();
						while (true) {
					        System.out.println("Esta seguro que quiere dar de baja el producto seleccionado? (ingrese 'si' para continuar, o 'no' para cancelar la operacion)");
					        seguro = scan.nextLine();
					        if (seguro.equals("si")) {
					        	break;
					        }
					        else if (seguro.equals("no")) {
					        	y = true;
					        	break;
					        }
					        else {
					        	System.out.println("Ingrese una opcion valida.");
					        }
						}
						if (y == true) {
							System.out.println("Operacion cancelada.");
							continue;
						}
						stock.bajaDeProducto(codigo);
					}
					
// 		1.5 Retroceder:
					else {
						break;
					}
				}
			}
			
// 2 Manejar la caja:
			else if (num.equals("2")) {
				while (true) {
					String num3;
					while(true) {
						System.out.println("\nIngrese '1' para agregar productos al carrito\nIngrese '2' para modificar la cantidad seleccionada de un producto\nIngrese '3' para eliminar un producto del carrito\nIngrese '4' para cancelar la compra\nIngrese '5' para ver el listado en stock\nIngrese '6' para finalizar la compra\nIngrese '7' para retroceder");
						num3 = scan.nextLine();
						System.out.println();
						if (num3.equals("1") || num3.equals("2") || num3.equals("3") || num3.equals("4") || num3.equals("5") || num3.equals("6") || num3.equals("7")) {
							break;
						}
						else {
							System.out.println("El valor ingresado es invalido.");
						}
					}
					
//		2.1 Agregar productos al carrito:
					if (num3.equals("1")) {
						int codigoProducto;
						int cantidadSolicitada;
						
						// 2.1.1 codigo del producto que desea añadir al carrito
						while (true){
							System.out.println("Ingrese el codigo del producto que desea añadir al carrito (-1 para cancelar la operacion): ");
							
							try {
					            codigoProducto = scan.nextInt();
					            if (stock.existeCodigo(codigoProducto) || codigoProducto == -1) {
					            	break;
					            }
					            else {
					            	System.out.println("Ingrese un codigo existente.");
					            }
					        } catch (InputMismatchException e) {
					            System.out.println("Error: Debe ingresar un número entero.");
					            scan.nextLine();
					        }
						}
						if (codigoProducto == -1) {
							System.out.println("Operacion cancelada.");
				            scan.nextLine();
							continue;
						}
				
						// 2.1.2 cantidad de productos que desea añadir al carrito
						while (true){
							System.out.println("Ingrese la cantidad del producto que desea añadir al carrito (-1 para cancelar la operacion): ");
							
							try {
								cantidadSolicitada = scan.nextInt();
					            if (cantidadSolicitada > 0 || cantidadSolicitada == -1) {
						            break;
					            }
					            else {
						            System.out.println("Error: ingrese un valor valido (no se permiten numeros negativos).");
					            }
					        } catch (InputMismatchException e) {
					            System.out.println("Error: Debe ingresar un número entero.");
					            scan.nextLine();
					        }
						}
						if (cantidadSolicitada == -1) {
							System.out.println("Operacion cancelada.");
							scan.nextLine();
							continue;
						}
						
						// 2.1.3 confirmacion de agregacion de productos al carrito
						String seguro = "0";
						boolean y = false;
						scan.nextLine();
						while (true) {
					        System.out.println("Esta seguro que quiere agregar los productos seleccionados al carrito? (ingrese 'si' para continuar, o 'no' para cancelar la operacion)");
					        seguro = scan.nextLine();
					        if (seguro.equals("si")) {
					        	break;
					        }
					        else if (seguro.equals("no")) {
					        	y = true;
					        	break;
					        }
					        else {
					        	System.out.println("Ingrese una opcion valida.");
					        }
						}
						if (y == true) {
							System.out.println("Operacion cancelada.");
							continue;
						}
						venta.agregarProducto(codigoProducto, cantidadSolicitada);
					}
					
//		2.2 Modificar cant seleccionada de un producto:
					if (num3.equals("2")) {
						int codigoProducto;
						int cantidadSolicitada;
						
						// 2.2.1 codigo de producto que se desea modificar la cantidad seleccionada
						while (true){
							System.out.println("Ingrese el codigo del producto del cual desea modificar la cantidad seleccionada (-1 para cancelar la operacion): ");
							
							try {
								codigoProducto = scan.nextInt();
					            if (codigoProducto > 0 || codigoProducto == -1) {
						            break;
					            }
					            else {
						            System.out.println("Error: ingrese un valor valido (no se permiten numeros negativos).");
					            }
					        } catch (InputMismatchException e) {
					            System.out.println("Error: Debe ingresar un número entero.");
					            scan.nextLine();
					        }
						}
						if (codigoProducto == -1) {
							System.out.println("Operacion cancelada.");
							scan.nextLine();
							continue;
						}
						
						// 2.2.2 nueva cantidad seleccionada del producto en el carrito
						while (true){
							System.out.println("Ingrese la nueva cantidad del producto que desea añadir al carrito: ");
							
							try {
								cantidadSolicitada = scan.nextInt();
					            if (cantidadSolicitada > 0 || cantidadSolicitada == -1) {
						            break;
					            }
					            else {
						            System.out.println("Error: ingrese un valor valido (no se permiten numeros negativos, para eliminar el producto del carrito seleccione la opcion correspondiente).");
					            }
					        } catch (InputMismatchException e) {
					            System.out.println("Error: Debe ingresar un número entero.");
					            scan.nextLine();
					        }
						}
						if (cantidadSolicitada == -1) {
							System.out.println("Operacion cancelada.");
							scan.nextLine();
							continue;
						}
						
						// 2.2.3 confirmacion de modificar cantidad del producto añadido al carrito
						String seguro = "0";
						boolean y = false;
						scan.nextLine();
						while (true) {
					        System.out.println("Esta seguro que quiere modificar el producto seleccionado? (ingrese 'si' para continuar, o 'no' para cancelar la operacion)");
					        seguro = scan.nextLine();
					        if (seguro.equals("si")) {
					        	break;
					        }
					        else if (seguro.equals("no")) {
					        	y = true;
					        	break;
					        }
					        else {
					        	System.out.println("Ingrese una opcion valida.");
					        }
						}
						if (y == true) {
							System.out.println("Operacion cancelada.");
							continue;
						}
						venta.modificarCant(codigoProducto, cantidadSolicitada);
					}
					
//		2.3 Eliminar producto del carrito:
					if (num3.equals("3")) {
						int codigoProducto;
						
						// 2.3.1 ingreso del codigo del producto a eliminar del carrito
						while (true){
							System.out.println("Ingrese el codigo del producto que desea eliminar (-1 para cancelar la operacion): ");
							
							try {
								codigoProducto = scan.nextInt();
					            if (stock.existeCodigo(codigoProducto) || codigoProducto == -1) {
						            break;
					            }
					            else {
						            System.out.println("\nError: ingrese un codigo existente.\n");
					            }
					        } catch (InputMismatchException e) {
					            System.out.println("Error: Debe ingresar un número entero.");
					            scan.nextLine();
					        }
						}
						if (codigoProducto == -1) {
							System.out.println("Operacion cancelada.");
							scan.nextLine();
							continue;
						}
						
						// confirmacion elimacion del producto del carrito
						String seguro = "0";
						boolean k = false;
						scan.nextLine();
						while (true) {
						    System.out.println("¿Está seguro de que quiere modificar el producto seleccionado? (ingrese 'si' para continuar, o 'no' para cancelar la operación)");
						    seguro = scan.nextLine();
						    if (seguro.equals("si")) {
						        break;
						    } else if (seguro.equals("no")) {
						        k = true;
						        break;
						    } else {
						        System.out.println("Ingrese una opción válida.");
						    }
						}

						if (k) {
						    System.out.println("Operación cancelada.");
						    continue;
						}

						venta.eliminarProducto(codigoProducto);
					}
					
//		2.4 Cancelar compra:
					if (num3.equals("4")) {
						venta.eliminarPedido();
					}
					
//		2.5 ver listado en stock:
					if (num3.equals("5")) {
						stock.listado();
					}
					
//		2.6 Finalizar compra:
					if (num3.equals("6")) {
						venta.totalAPagar();
					}
					
//		2.7 Retroceder
					if (num3.equals("7")) {
						break;
					}
				}
			}

// 3 Finalizar programa
			else {
				System.out.println("Programa finalizado con exito.");
	        	scan.close();
				break;
			}
		}
	}
}