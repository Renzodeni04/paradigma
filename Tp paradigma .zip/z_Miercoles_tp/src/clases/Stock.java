package clases;
import java.util.ArrayList;
import java.io.*;

public class Stock implements Serializable{

	public ArrayList<Productos> stockTotal;
	
	public void inicializar() {
	    if (!recuperar()) {
	        stockTotal = new ArrayList<>();
	    }
	}
	
	public void agregarStock(int codigo, String descripcion, int precioUnitario, int cantStock, int stockMin) {
		recuperar();
		Productos producto = new Productos();
	   	 	boolean y = true;
	        producto.insertarInfo(codigo, descripcion, precioUnitario, cantStock, stockMin);
	        for (Productos producto1 : stockTotal) {
	            if (producto1.codigo == codigo) {
	            	 System.out.println("El codigo proporcionado ya esta asignado a otro producto");
	            	 System.out.println("");
	            	 y = false;
	            	 break;
	            }
	        }
	        if (y == true) {
	            stockTotal.add(producto);
	            System.out.println("Producto guardado exitosamente.");
	            guardar();
	        }
		}

	
	//Se ingresa la cantidad de nuevos productos que llegaron, no el total. Osea que el numero que se ingrese se sumara al total que ya hay.
	public void actualizarStock(int codigo, int cantModificar) {
		recuperar();
		boolean x = false;
		
		 for (Productos producto : stockTotal) {
	            if (producto.codigo == codigo) {
	                producto.cantStock = producto.cantStock + cantModificar;
	                guardar();
	                x = true;
	                break;
	            }
		 }
		 if (x == false) {
			 System.out.println("El codigo proporcionado no fue encontrado");
		 }
	}
	
	public int revisarStockMin(int codigo) {
		recuperar();
		for (Productos producto : stockTotal) {
            if (producto.codigo == codigo) {
                return producto.stockMin;
            }
        }
		System.out.println("No se encontro el codigo ingresado");
        return -1;
	}
	
	//Chequear que se imprima bien, y posiblemente modificar la impresion por pantalla, creo que no queda muy bien como lo deje
    public void listado() {
		recuperar();
        System.out.println("Listado de Stock del Minimercado");
        System.out.println(String.format("%-15s %-10s %-20s %-15s %-12s", "Código", "Cantidad", "Descripción", "Precio Unitario", "Stock Mínimo"));
        
        for (Productos producto : stockTotal) {
            String marca = (producto.cantStock < producto.stockMin) ? "*" : "-";
            System.out.println(String.format("%-15d %-10d %-20s %-15d %-12d", producto.codigo, producto.cantStock, producto.descripcion, producto.precioUnitario, producto.stockMin));
        }
    }

	//COntrolar q devuelva si borro o no
	public void bajaDeProducto(int codigo) {
		recuperar();
	    stockTotal.removeIf(producto -> producto.codigo == codigo);
	    guardar();
	}

	
	public int devolverPrecioProducto(int codigo) {
		recuperar();
		for (Productos producto : stockTotal) {
            if (producto.codigo == codigo) {
            	return producto.precioUnitario;
            }
		}
		System.out.println("No se encontro el codigo ingresado");
		return -1;
	}
	
	public int cantidadEnStock(int codigo) {
		recuperar();
		for (Productos producto : stockTotal) {
            if (producto.codigo == codigo) {
            	return producto.cantStock;
            }
		}
		return 0;
	}
	
	public boolean existeCodigo(int codigo) {
		for (Productos producto : stockTotal) {
            if (producto.codigo == codigo) {
            	return true;
            }
		}
		return false;
	}
	
	public boolean guardar() {
        try {
            FileOutputStream fout = new FileOutputStream("Stock.bin");
            ObjectOutputStream out = new ObjectOutputStream(fout);
            out.writeObject(stockTotal);
            out.close();
            return true;
        } catch (IOException e) {
            e.printStackTrace();
            return false;
        }
    }
	public ArrayList<Productos> devolverStock(){
		return stockTotal;
	}
	
	public boolean recuperar() {
        try {
            FileInputStream fi = new FileInputStream("Stock.bin");
            ObjectInputStream fs = new ObjectInputStream(fi);
            stockTotal = (ArrayList<Productos>) fs.readObject();
            fs.close();
            return true;
        } catch (IOException | ClassNotFoundException e) {
            e.printStackTrace();
            return false;
        }
    }
}