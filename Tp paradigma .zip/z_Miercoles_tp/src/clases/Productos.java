package clases;

import java.io.Serializable;

public class Productos  implements Serializable{
	
	public int codigo = -1;
	public String descripcion = "";
	public int precioUnitario = -1;
	public int cantStock = -1;
	public int stockMin = -1;
	
	public void insertarInfo(int codigo, String descripcion, int precioUnitario, int cantStock, int stockMin) {
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.precioUnitario = precioUnitario;
        this.cantStock = cantStock;
        this.stockMin = stockMin;
    }
}