package clases;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Venta {

	ArrayList<int[]> pedidos = new ArrayList<>();
	Stock stock = new Stock();
	
	public void inicializarVenta() {
    	stock.inicializar();
	}
    public void agregarProducto(int codigoProducto, int cantidadPedida) {
    	stock.recuperar();
    	if (stock.cantidadEnStock(codigoProducto) >= cantidadPedida) {
            int[] pedido = {codigoProducto, cantidadPedida};
            pedidos.add(pedido);
            restarStock(codigoProducto, cantidadPedida);
            if (stock.revisarStockMin(codigoProducto) >= stock.cantidadEnStock(codigoProducto)) {
            	System.out.println("Advertencia, el stock esta por debajo del stock minimo");
            }
    	}
    	else {
    		System.out.println("Error, solicito un monto mayor de productos al stock actual.");
    	}
    }
    
    public void modificarCant(int codigo, int cant) {
    	stock.recuperar();
    	boolean x = false;
    	for (int[] pedido : pedidos) {
            if (pedido[0] == codigo) {
            	sumarStock(codigo, pedido[1]);
            	pedido[1] = cant;
            	restarStock(codigo, pedido[1]);
            	x = true;
            	break;
            }
    	}
    	if (x == false) {
    		System.out.println("Codigo no encontrado.");
    	}
    }
    
    public void eliminarProducto(int codigo) {
    	stock.recuperar();
    	for (int[] pedido : pedidos) {
            if (pedido[0] == codigo) {
            	sumarStock(codigo, pedido[1]);
            	pedidos.remove(pedido);
            }
    	}
    }
    
    public void eliminarPedido() {
    	stock.recuperar();
    	if (!(pedidos.isEmpty())) {
	    	for (int[] pedido : pedidos) {
	    		sumarStock(pedido[0], pedido[1]);
	    	}
	    	pedidos.clear();
			System.out.println("Compra cancelada con exito.");
    	}
    	else {
    		System.out.println("Error, no tiene nada en el carrito.");
    	}
    }
    
    public int calcularTotal() {
    	stock.recuperar();
    	if (!pedidos.isEmpty()) {
	        int total = 0;
	        for (int[] pedido : pedidos) {
	            int x = stock.devolverPrecioProducto(pedido[0]);
	            x = x * pedido[1];
	            total = total + x;
	            x = 0;
	        }
	        return total;
    	}
    	else {
    		System.out.println("Error, no tiene nada en el carrito.");
    		return -1;
    	}
    }
    
    public void restarStock(int codigo, int cant) {
    	stock.recuperar();
        stock.actualizarStock(codigo, -cant);
    }
    
    public void sumarStock(int codigo, int cant) {
    	stock.recuperar();
        stock.actualizarStock(codigo, cant);
    }
    
    public void procesarPago() {
    	stock.recuperar();
    	totalAPagar();
    }
    
    // ESTO ES PARA EL PROFESOR: no le pusimos la opcion para cancelar o confirmar la compra tras haber recibido el costo de la compra ya que este programa lo estaria usando el empleado (seria la caja). Luego le tiene que informar al comprador el costo total, y este decidira si pagar o no.
    public void totalAPagar() {
    	int monto = calcularTotal();
    	if (monto != -1) {
        	Scanner scan = new Scanner(System.in);
    		while (true) {
		    	stock.recuperar();
		    	int formaDePago = -1;
		    	int cantCuotas = -1;
		    	
		    	// Eleccion de metodo de pago
		    		while (true) {
		    			System.out.println("Elija el metodo de pago, las opciones son: '1' = debito, '2' = efectivo, '3' = credito ('-1' para cancelar la operacion): ");
		    			
		    			try {
			    			formaDePago = scan.nextInt();
			    			System.out.println("");
			    			if (formaDePago == 1 || formaDePago == 2 || formaDePago == 3 || formaDePago == -1) {
			    				break;
			    			}
			    			else {
			    				System.out.println("Error, ingrese una opción valida");
			    			}
		    			} catch (InputMismatchException e) {
				            System.out.println("Error: Debe ingresar un número entero.");
				            scan.nextLine();
				        }
		    		}
		    		if (formaDePago == -1) {
						System.out.println("Operacion cancelada.");
						scan.nextLine();
						break;
					}
		    		
		    		//Paga con debito osea no se modifica nada
		    		if (formaDePago == 1) {
		    			System.out.println("El total a pagar es: " + monto);
		    			pedidos.clear();
		    			break;
		    		}
		    		//Paga con efectivo, 10% de descuento
		    		else if (formaDePago == 2) {
		    			monto = monto - (monto / 10);
		    			System.out.println("El total a pagar es: " + monto);
		    			pedidos.clear();
		    			break;
		    		}
		    		//Paga con credito
		    		else {
		    			while (true) {
		    				System.out.println("¿En cuantas cuotas quiere pagar? las opciones son 2, 3 o 6 coutas: ");
		    				cantCuotas = scan.nextInt();
		    				System.out.println("");
		    				if (cantCuotas == 2 || cantCuotas == 3 || cantCuotas == 6) {
		    					break;
		    				}
		    				else {
		    					System.out.println("Error, ingrese una opción valida.");
		    				}
		    			}
		    			if (cantCuotas == 2) {
		    				int valorRecargo = (monto * 6) / 100;
		    				monto = monto + valorRecargo;
		    			}
		    			else if (cantCuotas == 3) {
		    				int valorRecargo = (monto * 12) / 100;
		    				monto = monto + valorRecargo;
		    			}
		    			else {
		    				int valorRecargo = (monto * 20) / 100;
		    				monto = monto + valorRecargo;
		    		}
		    		System.out.println("El total a pagar es: " + monto);
		    		pedidos.clear();
		    		break;
		    	}
    		}
	    }
    }
}